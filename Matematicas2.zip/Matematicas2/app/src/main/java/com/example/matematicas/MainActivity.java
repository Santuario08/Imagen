package com.example.matematicas;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private EditText PrimerNumero;
    private EditText SegundoNumero;
    private Button Sumar;
    private Button Restar;
    private Button Multiplicar;
    private Button Dividir;
    private TextView Resultado;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);
        PrimerNumero = findViewById(R.id.PrimerNumero);
        SegundoNumero = findViewById(R.id.SegundoNumero);
        Resultado = findViewById(R.id.Resultado);

        Sumar = findViewById(R.id.Sumar);
        Sumar.setOnClickListener(this::Suma);

        Restar = findViewById(R.id.Restar);
        Restar.setOnClickListener(this::Resta);

        Multiplicar = findViewById(R.id.Multiplicar);
        Multiplicar.setOnClickListener(this::Multiplica);

        Dividir = findViewById(R.id.Dividir);
        Dividir.setOnClickListener(this::Divide);
    }

    public void Suma(View view) {
        String Valor1 = PrimerNumero.getText().toString();
        String Valor2 = SegundoNumero.getText().toString();
        int num1 = Integer.parseInt(Valor1);
        int num2 = Integer.parseInt(Valor2);
        int result = num1 + num2;
        String A = String.valueOf(result);
        Resultado.setText(A);
    }

    public void Resta(View view) {
        String Valor1 = PrimerNumero.getText().toString();
        String Valor2 = SegundoNumero.getText().toString();
        int num1 = Integer.parseInt(Valor1);
        int num2 = Integer.parseInt(Valor2);
        int result = num1 - num2;
        String A = String.valueOf(result);
        Resultado.setText(A);
    }

    public void Multiplica(View view) {
        String Valor1 = PrimerNumero.getText().toString();
        String Valor2 = SegundoNumero.getText().toString();
        int num1 = Integer.parseInt(Valor1);
        int num2 = Integer.parseInt(Valor2);
        int result = num1 * num2;
        String A = String.valueOf(result);
        Resultado.setText(A);
    }
    public void Divide(View view) {
        String Valor1 = PrimerNumero.getText().toString();
        String Valor2 = SegundoNumero.getText().toString();
        int num1 = Integer.parseInt(Valor1);
        int num2 = Integer.parseInt(Valor2);
        int result = num1 / num2;
        String A = String.valueOf(result);
        Resultado.setText(A);
    }
}

